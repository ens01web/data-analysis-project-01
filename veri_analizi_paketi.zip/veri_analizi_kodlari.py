import pandas as pd
import matplotlib.pyplot as plt

# Veriyi oku
df = pd.read_excel("satis_verisi_proje1.xlsx")
print(df.head())

# Toplam gelir
toplam_gelir = df["Toplam_Tutar"].sum()
print("Toplam Gelir:", toplam_gelir, "TL")

# Günlük gelir
gunluk_gelir = df.groupby("Tarih")["Toplam_Tutar"].sum()
print(gunluk_gelir)

# En çok satılan ürün
en_cok_satilan = df.groupby("Ürün")["Adet"].sum().sort_values(ascending=False)
print("En Çok Satılan Ürünler:")
print(en_cok_satilan)

# Grafik
en_cok_satilan.plot(kind="bar", title="Ürün Bazında Satış Adedi", color="skyblue")
plt.ylabel("Adet")
plt.xlabel("Ürün")
plt.grid(True)
plt.show()
